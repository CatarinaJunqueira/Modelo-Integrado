



function [x,y,b,v]=gera_variaveis()

 [x]=gera_variavel_x();
 
 [y]=gera_variavel_y();
 
 [b]=gera_variavel_b();
 
 [v]=gera_variavel_v();


end