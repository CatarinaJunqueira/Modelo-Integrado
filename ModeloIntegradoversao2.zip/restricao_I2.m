
function model = restricao_I2(model,N,mapObj_v,nvar)

nr = N*(T-1);
A1 = sparse(nr,nvar);
rest_name = cell(1,nr);
w=0;

for n=1:N
   for t=1:T-1   
      w = w +1;
      rest_name(w) = {strcat('restI2_',int2str(n),'_',int2str(t))}; 
      A1(w,mapObj_v(strcat('v_',int2str(n),'_',int2str(t))))=1;
      A1(w,mapObj_v(strcat('v_',int2str(n),'_',int2str(t+1))))=-1;             
   end    
end

rest_name = char(rest_name);
lhs = -inf(nr,1);
rhs = sparse(nr,1);
model.addRows(lhs,A1,rhs,rest_name);
end