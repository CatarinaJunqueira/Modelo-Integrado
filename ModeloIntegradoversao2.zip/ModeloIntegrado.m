
% P1 = [0 0 5 ; 6 0 4 ; 7 0 3 ; 8 2 1];
% P2 = [0 0 16 ; 10 0 11 ; 12 17 13 ; 14 15 9];
% P3 = [0 0 25 ; 0 24 23 ; 0 22 21 ; 20 19 18];
% P{1,1}=P1;
% P{2,1}=P2;
% P{3,1}=P3;
% 
% keySet={1     2     3     4     5     6     7     8     9    10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25};
% valueSet = {[1,2],[1,3],[1,4],[1,2],[1,3],[1,4],[1,2],[1,3],[2,3],[2,4],[2,3],[2,4],[2,3],[2,4],[2,3],[2,4],[2,3],[3,4],[3,4],[3,4],[3,4],[3,4],[3,4],[3,4],[3,4]};
% mapObj = containers.Map(keySet,valueSet);

function  [nmov,Pt,Navio] = ModeloIntegrado(P,R,C)

omega=cell(length(P),1); % omega = conjunto dos indices dos conteineres em cada patio
for i= 1: length(P)
   omega{i,1}=P{i,1}(P{i,1}~=0)';
end

N=zeros(length(P),1); % N = quantidade de conteineres em cada patio
for i= 1: length(P)
    N(i)=nnz(P{i,1});
end
T=N;

H=zeros(length(P),1); % H = numero de linhas de cada patio
for i= 1: length(P)
    H(i)=size(P{i,1},1);
end

W=zeros(length(P),1);  % W = numero de colunas de cada patio
for i= 1: length(P)
    W(i)=size(P{i,1},2);
end

model = Cplex('ModeloIntegrado');
model.Model.sense = 'minimize';

nvar = 0; 

%------------------------------------------------------------%
%--------------------  Variaveis  ---------------------------%

[model,mapObj_x,nvar] = variavel_x(model,omega,N,H,W,T,nvar);
nx=nvar;

[model,mapObj_y,nvar] = variavel_y(model,omega,N,H,W,T,nvar);

[model,mapObj_b,nvar] = variavel_b(model,omega,N,H,W,T,nvar);

[model,mapObj_v,nvar] = variavel_v(model,omega,N,T,nvar);

[model,mapObj_w,nvar] = variavel_w(model,N,R,C,nvar);

[model,mapObj_z,nvar] = variavel_z(model,omega,N,T,R,C,nvar);

%------------------------------------------------------------%
%-------------------  Restricoes  ---------------------------%

%Patio:
model = restricao_P0(model,omega,N,H,W,mapObj_b,nvar,P);

model = restricao_P1(model,omega,N,H,W,T,mapObj_b,mapObj_v,nvar);

model = restricao_P2(model,omega,N,H,W,T,mapObj_b,nvar);

model = restricao_P3(model,omega,N,H,W,T,mapObj_b,nvar);

model = restricao_P6(model,omega,N,H,W,T,mapObj_x,mapObj_y,mapObj_b,nvar);

model = restricao_P7(model,omega,N,H,W,T,mapObj_y,mapObj_v,nvar);

model = restricao_P8(model,omega,N,H,W,T,mapObj_x,nvar);

model = restricao_P9(model,omega,N,H,W,mapObj_x,mapObj_b,nvar);

model = restricao_P10(model,omega,N,H,W,T,mapObj_x,nvar);

model = restricao_PA(model,omega,N,H,W,T,mapObj_x,mapObj_y,mapObj_b,nvar);


%Integracao:
model = restricao_I1(model,N,T,mapObj_v,nvar);

model = restricao_I2(model,N,mapObj_v,nvar);

model = restricao_I3(model,N,R,C,T,mapObj_v,mapObj_z,nvar);

model = restricao_I4(model,N,R,C,T,mapObj_z,nvar);

model = restricao_I5(model,N,R,C,T,mapObj_z,nvar);


%Navio:
model = restricao_N1(model,N,R,C,T,mapObj_w,nvar);

model = restricao_N2(model,N,R,C,mapObj_w,mapObj_z,nvar);

model = restricao_N3(model,N,R,C,mapObj_z,nvar);

model = restricao_N4(model,N,R,C,mapObj_w,nvar);



fprintf('Modelo Integrado criado\n');
%model.writeModel('model.lp');
%model.Param.mip.strategy.search.Cur=4;
model.solve();

% Display solution
fprintf ('\nSolution status = %s\n',model.Solution.statusstring);
fprintf ('Valor da Funcao Objetivo: %f\n', model.Solution.objval);
fprintf ('Numero de remanejamentos: %f\n', sum(model.Solution.x(1:nx)));

Pt = obterP(model,mapObj_b,H,W,N,T);
nmov=model.Solution.objval;


