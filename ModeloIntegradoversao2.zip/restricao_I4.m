

function model = restricao_I4(model,N,R,C,T,mapObj_z,nvar)

nr = W*H*T;
A1 = sparse(nr,nvar);
rest_name = cell(1,nr);
w=0;
for r=1:R
   for c=1:C
       for t=1:T
          w = w +1;
          rest_name(w) = {strcat('restI4_',int2str(r),'_',int2str(c),'_',int2str(t)) };

          for n=1:N             
               A1(w,mapObj_z(strcat('z_',int2str(n),'_',int2str(t),'_',int2str(r),'_',int2str(c))))=1;          
          end
       end       
   end    
end

rest_name = char(rest_name);
lhs = -inf(nr,1);
rhs = ones(nr,1);
model.addRows(lhs,A1,rhs,rest_name);
end