% \sum_{n = 1}^{N} v_{nt} = t,  \\ \nonumber  t=1,\cdots,T

function model = restricao_I1(model,N,T,mapObj_v,nvar)

nr = T;
A1 = sparse(nr,nvar);
rest_name = cell(1,nr);
w=0;
 
lhs = zeros(nr,1);
for t=1:T
  w = w +1;
  rest_name(w) = {strcat('restI1_',int2str(t))};

  lhs(w) = t;
      
  for n=1:N            
      A1(w,mapObj_v(strcat('v_',int2str(n),'_',int2str(t))))=1;         
  end

end

rest_name = char(rest_name);

rhs = lhs;
model.addRows(lhs,A1,rhs,rest_name);
end