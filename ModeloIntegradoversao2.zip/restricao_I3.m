

function model = restricao_I3(model,N,R,C,T,mapObj_v,mapObj_z,nvar)

nr = N*T;
A1 = sparse(nr,nvar);
rest_name = cell(1,nr);
w=0;


for n=1:N
   for t=1:T
       w = w +1;
       rest_name(w) = {strcat('restI3_',int2str(n),'_',int2str(t))}; 
       A1(w,mapObj_v(strcat('v_',int2str(n),'_',int2str(t))))=-1;
      
      for r=1:R
         
          for c=1:C
             
               A1(w,mapObj_z(strcat('z_',int2str(n),'_',int2str(t),'_',int2str(r),'_',int2str(c))))=1;
          end
          
      end
       
   end
    
end

rest_name = char(rest_name);
lhs = zeros(nr,1);
rhs = lhs;
model.addRows(lhs,A1,rhs,rest_name);
end